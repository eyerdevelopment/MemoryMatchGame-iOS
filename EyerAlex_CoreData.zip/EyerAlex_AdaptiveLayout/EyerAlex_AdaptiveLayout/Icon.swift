//
//  Icon.swift
//  EyerAlex_AdaptiveLayout
//
//  Created by Alex Eyer on 10/10/22.
//

import Foundation

class Icon{
    
    var iconID = ""
    var iconFlipped = false
    var iconMatched = false
     
}
