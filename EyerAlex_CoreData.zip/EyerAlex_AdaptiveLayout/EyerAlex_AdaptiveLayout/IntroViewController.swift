//
//  IntroViewController.swift
//  EyerAlex_AdaptiveLayout
//
//  Created by Alex Eyer on 10/22/22.
//

import UIKit
import CoreData


class IntroViewController: UIViewController, UITextFieldDelegate {
    
    
    @IBOutlet weak var nameInput: UITextField!
    @IBOutlet weak var startGameButton: UIButton!
    @IBOutlet weak var scoresDisplay: UITextView!
    
    private var managedContext:NSManagedObjectContext!
    private var entityDescription: NSEntityDescription!
    
    
    
    private var hsName: String!
    private var hsTime: String!
    private var hsTaps: Int!
    private var hsDate: String!
    
    
    private var appDelegate = (UIApplication.shared.delegate as! AppDelegate)
    
    var hs = [(taps: Int, name: String, time: String, date: String)]()
    var count = 0
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameInput.delegate = self
        setUp()
        
        managedContext = appDelegate.persistentContainer.viewContext
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let dest = segue.destination as? ViewController{
            dest.userName = nameInput.text
        }
    }
    
    
    func setUp(){
        nameInput.text = ""
        startGameButton.isEnabled = false
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        setUp()
        scoresDisplay.text = ""
        loadScores()
    }
    
    
    func loadScores(){
        scoresDisplay.text = ""
        hs.removeAll()
        //let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "HighScore")
        let fetchRequest : NSFetchRequest<HighScore> = HighScore.fetchRequest()
        do{
            let results = try managedContext.fetch(fetchRequest)
            
            for (h, obj) in results.enumerated(){
                hsTaps = obj.value(forKey: "hsTaps") as? Int
                hsName = obj.value(forKey: "hsName") as? String
                hsTime = obj.value(forKey: "hsTime") as? String
                hsDate = obj.value(forKey: "hsDate") as? String
                
                
                hs.append((taps: hsTaps, name: hsName, time: hsTime, date: hsDate))
                
                scoresDisplay.text += "Name: \(hs[h].name.capitalized)\n Tap Count: \(hs[h].taps.description)\n \(hs[h].time) seconds\n Date: \(hs[h].date)\n\n"
            }
        }
        catch{
            assertionFailure()
        }
        
        if hsTaps == nil {
            scoresDisplay.text = "No Scores To Display"
        }
        
    }
    
    
    
    //Enables Play button after user has entered their name (or anythng for now)
    func textFieldDidChangeSelection(_ textField: UITextField) {
        if nameInput.text == "" {
            startGameButton.isEnabled = false
        }
        else {
            self.startGameButton.isEnabled = true
        }
    }
    
    

    
    
//    func sortTaps(data: Int, hs: [HighScore]) -> [HighScore] {
//        var newData: [HighScore] = []
//        for (offset, highscore) in hs.enumerated() {
//            if offset == 0 {
//                newData += [highscore]
//            } else {
//                for (offset,newHighScore) in newData.enumerated() {
//                    if highscore.hsTaps >= newHighScore.hsTaps {
//                        newData.insert(highscore, at: offset)
//                        break
//                    } else if offset == (newData.count - 1) {
//                        newData.append(highscore)
//                    }
//                }
//            }
//        }
//        return newData
//    }
//    
    
    
    
    
}
