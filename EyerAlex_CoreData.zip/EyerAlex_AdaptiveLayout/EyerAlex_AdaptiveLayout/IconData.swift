//
//  IconData.swift
//  EyerAlex_AdaptiveLayout
//
//  Created by Alex Eyer on 10/10/22.
//



import Foundation

class IconData{

    // Create matching pair 
    func createMatch() ->[Icon]{
        // Empty array to create ID
        var getID = [Int]()
        // Empty array for matching Icons
        var getMatch = [Icon]()
        // Randomly generate 20/30 cards
        //**Showing 30 to display all icons for the phone
        while getID.count < 15 {
            
            // Generate random ID
            let randomID = Int.random(in: 0...14)
            
            if getID.contains(randomID) == false {
                // Create two new card objects
                let matchOne = Icon()
                let matchTwo = Icon()
                
                // Set image names
                matchOne.iconID = "Icon\(randomID)"
                matchTwo.iconID = "Icon\(randomID)"
                
                // Add them to the array
                getMatch += [matchOne, matchTwo]
                
                // Add this number to the list of generated numbers
                getID.append(randomID)
            }
        }
        // Randomize the cards within the array
        getMatch.shuffle()
        
        // Return the array
        return getMatch
    }
    
    
    

    
}
