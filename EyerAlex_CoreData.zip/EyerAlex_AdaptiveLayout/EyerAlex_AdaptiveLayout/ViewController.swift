//
//  ViewController.swift
//  EyerAlex_AdaptiveLayout
//
//  Created by Alex Eyer on 10/10/22.
//

import UIKit
import CoreData

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    
    private var managedContext:NSManagedObjectContext!
    
    
    @IBOutlet var collectionView: UICollectionView!
    @IBOutlet var timerLabel: UILabel!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    @IBOutlet weak var tapCountLabel: UILabel!
    @IBOutlet weak var welcomeLabel: UILabel!
    
    
    var iconArray = [Icon]()
    var data = IconData()
    var timer: Timer?
    var milliseconds: Double = 0.0
    var firstTapped: IndexPath?
    var tapCount: Int = 0
    var userName: String!
   // var newhs:

    var appDelegate = (UIApplication.shared.delegate as! AppDelegate)

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        managedContext = appDelegate.persistentContainer.viewContext
        setUp()
        
    }


    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return iconArray.count
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell_ID_1", for: indexPath) as! CollectionViewCell
        return cell
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        // Configure the state of the cell based on the properties of the Card that it represents
        let iconCell = cell as? CollectionViewCell
        
        // Get the card from the card array
        let icon = iconArray[indexPath.row]
        
   
        if stopButton.isHidden == true{
            iconCell?.hiddenIcon.backgroundColor = .systemGray5
        }else{
            iconCell?.hiddenIcon.backgroundColor = .gray
        
            // Finish configuring the cell
            // Waits to fire until play button is pressed
            iconCell?.setIcons(icon)
        }

    }

    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath) as? CollectionViewCell
        
        // Check if there's any time remaining. Don't let the user interact if the time is 0
        if milliseconds <= 0 {
            return
        }
        
        // Check the status of the card to determine how to flip it
        if cell?.icon?.iconFlipped == false && cell?.icon?.iconMatched == false {
            // Flip the card up
            cell?.showIcon()
            
            // Check if this is the first card that was flipped or the second card
            if firstTapped == nil {
                // This is the first card flipped over
                firstTapped = indexPath
                tapCount += 1
            }
            else {
                // Second card that is flipped
                // Run the comparison logic
                tapCount += 1
                checkForMatch(indexPath)
            }
        }
        
        tapCountLabel.text = "Tap Count: \(tapCount.description)"
        
    }
    
    
    
    func checkForMatch(_ secondTapped: IndexPath ){
        //Get the cells for the two cards that were revealed
        let iconOneCell = collectionView.cellForItem(at: firstTapped!) as? CollectionViewCell
        let iconTwoCell = collectionView.cellForItem(at: secondTapped) as? CollectionViewCell
        
        //Get the icons for the two cards that were revelead
        let iconOne = iconArray[firstTapped!.row]
        let iconTwo = iconArray[secondTapped.row]
        
        //Compare the icons
        if iconOne.iconID == iconTwo.iconID {
            
            //matched, set status to true
            iconOne.iconMatched = true
            iconTwo.iconMatched = true
            
            //remove from grid
            iconOneCell?.clearIcon()
            iconTwoCell?.clearIcon()
            
            // Was that the last pair?
            endGame()
            
        } else {
            
            //Not a match, set status of icons
            iconOne.iconMatched = false
            iconTwo.iconMatched = false
            
            //Flip both back
            iconOneCell?.hideIcon()
            iconTwoCell?.hideIcon()
            
        }
        // Reset
        firstTapped = nil
    }
    
    
    //start up settings for new games
    func setUp(){
        iconArray = data.createMatch()
        playButton.isEnabled = true
        playButton.isHidden = false
        stopButton.isEnabled = false
        stopButton.isHidden = true
        tapCountLabel.text = "Tap Count: 0"
        welcomeLabel.text = "Welcome, \(userName!.capitalized)!"
        collectionView.reloadData()
    }
    
    
    
    @objc func startTimer() {
        // Decrement the counter
        milliseconds -= 1
        
        // Update the label
        let seconds:Double = Double(milliseconds)/1000.0
        timerLabel.text = String(format: "Time Remaining: %.2f", seconds)
        
        // Stop the timer if it reaches zero
        if milliseconds == 0 {
            timerLabel.textColor = UIColor.red
            timer?.invalidate()
            // Check if the user has cleared all the pairs
            endGame()
        }
    }
    
    //Displays completed time with 2 decimals
    func timerDesc() -> String{
        var time = ""
        let seconds:Double = Double(milliseconds)/1000.0
        time = String(format: "%.2f", seconds)
        return time
    }
    
    
    
    func endGame() {
        // Check if there's any card that is unmatched
        // Assume the user has won, loop through all the cards to see if all of them are matched
        var winner = true
//        var timerText = timerLabel.text
        
        for icon in iconArray {
            if icon.iconMatched == false {
                // We've found a card that is unmatched
                winner = false
                break
            }
        }
        
        if winner == true {
            showAlert(title: "Congratulations!", message: "You Won!\nTaps: \(tapCount)\nTime: \(timerDesc()) / 60.00")
            timerLabel.textColor = UIColor.green
            
            timer?.invalidate()
            collectionView.reloadData()
        }
        else {
            if milliseconds <= 0 {
                showAlert(title: "Time's Up!", message: "You Were Too Slow! Taps: \(tapCount)")
                timer?.invalidate()
                collectionView.reloadData()
            }
        }
    }
    
    

    //Hides play button, enabls stop button
    //Sets message to "memorize"
    //Begins timer
    @IBAction func playButton(_ sender: UIButton) {
        milliseconds = 60000
        tapCount = 0
        collectionView.reloadData()
        stopButton.isEnabled = false
        stopButton.isHidden = false
        playButton.isEnabled = false
        playButton.isHidden = true
        timerLabel.text = "Memorize The Board!"
        
        // Start timer
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + .milliseconds(6000)) {
            self.timer = Timer.scheduledTimer(timeInterval: 0.001, target: self, selector: #selector(self.startTimer), userInfo: nil, repeats: true)
            RunLoop.main.add(self.timer!, forMode: .common)
            self.stopButton.isEnabled = true
        }
        
    }
      
    
    
    @IBAction func stopButton(_ sender: Any) {
        timer?.invalidate()
        stopAlert(title: "STOP", message: "What Would You Like To Do?")
    }
    
    
    
    func showAlert(title: String, message: String) {
        // Create alert
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        //reset game
        alert.addAction(UIAlertAction(title: "Play Again", style: .default, handler: { [self] (action: UIAlertAction!) in
            timerLabel.text = "Press Play To Begin"
            timerLabel.textColor = .white
            milliseconds = 0
            tapCount = 0
            tapCountLabel.text = "0"
            collectionView.reloadData()
            setUp()

        }))
        
        //SAVE SCORES BUTTON - with date
        alert.addAction(UIAlertAction(title: "Save Score", style: .destructive, handler: { [self] (action: UIAlertAction!) in
            
            var date = ""
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = DateFormatter.Style.short
            dateFormatter.timeStyle = DateFormatter.Style.none
            date = dateFormatter.string(from: Date())
            
            
            let newHS = HighScore(context: self.managedContext)
            
            newHS.setValue(tapCount, forKey: "hsTaps")
            newHS.setValue(userName, forKey: "hsName")
            newHS.setValue(timerLabel.text, forKey: "hsTime")
            newHS.setValue(date, forKey: "hsDate")
            appDelegate.saveContext()
            dismiss(animated: true)
            
        }))
        
        // Show alert
        present(alert, animated: true, completion: nil)

        
    }
    
    
        //Pause Game/Go to main menu
    func stopAlert(title: String, message: String) {
        // Create alert
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Continue", style: .default, handler: { [self] (action: UIAlertAction!) in
            timer = Timer.scheduledTimer(timeInterval: 0.001, target: self, selector: #selector(startTimer), userInfo: nil, repeats: true)
            RunLoop.main.add(timer!, forMode: .common)
            stopButton.isHidden = false
            stopButton.isEnabled = true
            playButton.isEnabled = false
            playButton.isHidden = true
        }))
        
        alert.addAction(UIAlertAction(title: "Quit", style: .destructive, handler: { (action: UIAlertAction!) in
            self.dismiss(animated: true)
        }))
        
        // Show alert
        present(alert, animated: true, completion: nil)
    }
    
    
    
    
    
    
    
    
}

