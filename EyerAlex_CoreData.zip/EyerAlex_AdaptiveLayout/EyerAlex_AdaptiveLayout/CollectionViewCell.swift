//
//  CollectionViewCell.swift
//  EyerAlex_AdaptiveLayout
//
//  Created by Alex Eyer on 10/10/22.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var displayIcon: UIImageView!
    @IBOutlet weak var hiddenIcon: UIImageView!
    
    var icon: Icon?
    
    func setIcons(_ icon: Icon) {
        self.icon = icon
        displayIcon.image = UIImage(named: icon.iconID)
        
        if icon.iconMatched == true {
            hiddenIcon.alpha = 0
            displayIcon.alpha = 0
            return
        }else {
            hiddenIcon.alpha = 1
            displayIcon.alpha = 1
        }
        
        presentIcon()
        
        if icon.iconFlipped == true {
            // Show the front image view
            showIcon(speed: 0)
            
        }else{
            // Show the back image view
            hideIcon(speed: 0, delay: 0)
        }
        
    }
    
    
    
    func showIcon(speed: TimeInterval = 0.3) {
        // Flip animation
        UIView.transition(from: hiddenIcon, to: displayIcon, duration: speed, options: [.showHideTransitionViews,.transitionFlipFromLeft], completion: nil)
        
        // Set the status of the card
        icon?.iconFlipped = true
    }
    
    
    
    func hideIcon(speed: TimeInterval = 0.3, delay: TimeInterval = 0.5) {
        // Set the status of the card
        icon?.iconFlipped = false
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delay) {
            // Flip down animation
            UIView.transition(from: self.displayIcon, to: self.hiddenIcon, duration: speed, options: [.showHideTransitionViews,.transitionFlipFromLeft], completion: nil)
        }
    }
    
    
    
    func clearIcon() {
        // Make the image views invisible
        hiddenIcon.alpha = 0
        
        UIView.animate(withDuration: 0.3, delay: 0.5, options: .curveEaseOut, animations: {
            self.displayIcon.alpha = 0
        }, completion: nil)
        
    }
    
    
    //Previews the icons and where they are before game begins
    func presentIcon() {
        icon?.iconFlipped = true
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 5.0) {
            UIView.transition(from: self.displayIcon, to: self.hiddenIcon, duration: 1, options: [.showHideTransitionViews,.transitionFlipFromLeft], completion: {_ in self.icon?.iconFlipped = false })
        }
    }
    
    
    
    
    
    
    

    
    
    
}
